# SEO API Handoff Package

Generated: 2026-06-15

This zip is a reusable handoff for deploying read-only SEO API tools into another website repository and using them from Codex.

Included APIs:

- Wincher
- Google Search Console
- PageSpeed Insights

## What Is Included

- `tools/seo/wincher/wincher_connector.py` - quick read-only API checks.
- `tools/seo/wincher/wincher_export.py` - CSV exporter for websites and keywords.
- `tools/seo/wincher/requirements.txt` - Python dependencies.
- `tools/seo/wincher/.env.example` - connector-local credential template.
- `tools/seo/google/gsc_export.py` - Google Search Console CSV exporter.
- `tools/seo/google/pagespeed_export.py` - PageSpeed Insights CSV exporter.
- `tools/seo/google/requirements.txt` - Google API dependencies.
- `tools/seo/google/.env.example` - connector-local Google credential template.
- `tools/seo/.env.example` - shared credential template.
- `docs/DEPLOYMENT.md` - install and deployment steps.
- `docs/CREDENTIALS.md` - where credentials go and what not to commit.
- `docs/WORKFLOW.md` - recommended SEO workflow after export.
- `docs/GOOGLE_SEARCH_CONSOLE_AND_PAGESPEED.md` - Google-specific setup and commands.
- `docs/GITIGNORE_SNIPPET.txt` - lines to add to the target repo `.gitignore`.
- `codex/GOAL.md` - target objective for another Codex session.
- `codex/CODEX_PROMPT.md` - prompt to paste into Codex in the target repository.

## What Is Not Included

- No real Wincher API token.
- No real `.env`.
- No generated output CSVs.
- No GitHub credentials.
- No Google OAuth client secret JSON.
- No Google OAuth token JSON.
- No Google service account JSON.
- No PageSpeed API key.

## Quick Start In Another Repository

From the target repository root:

```bash
mkdir -p tools/seo
```

Copy the `tools/seo` folder from this package into the target repository.

Add the ignore rules from:

```text
docs/GITIGNORE_SNIPPET.txt
```

Create credentials:

```bash
cp tools/seo/.env.example tools/seo/.env
```

Fill:

```text
WINCHER_API_TOKEN=
WINCHER_WEBSITE_ID=
GSC_SITE_URL=
GOOGLE_CLIENT_SECRETS_FILE=
GOOGLE_TOKEN_FILE=
GOOGLE_SERVICE_ACCOUNT_FILE=
GOOGLE_ACCESS_TOKEN=
PAGESPEED_API_KEY=
PAGESPEED_URLS=
WEBSITE_DOMAIN=
GITHUB_REPOSITORY=
```

Install dependencies:

```bash
cd tools/seo/wincher
python3 -m pip install -r requirements.txt
```

Find website IDs:

```bash
python3 wincher_connector.py --mode websites
```

Export Wincher data:

```bash
python3 wincher_export.py --mode all --website-id YOUR_WEBSITE_ID
```

Export Search Console:

```bash
cd ../google
python3 gsc_export.py --mode all
```

Run PageSpeed:

```bash
python3 pagespeed_export.py --strategy both
```

Outputs are written to:

```text
tools/seo/wincher/outputs/
tools/seo/google/outputs/
```
